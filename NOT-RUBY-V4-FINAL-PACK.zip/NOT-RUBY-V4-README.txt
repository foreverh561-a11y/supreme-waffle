NOT RUBY V4 // FINAL PACK

FILES
1. not-ruby-v4-final.txt
   Main NOT RUBY V4 client menu.

2. not-ruby-v4-server-fling.txt
   Companion server component for SERVER FLING.
   Put this as a Script in ServerScriptService in YOUR OWN Roblox experience.

PLACEID
The current source still contains:
local SHOOTER_ALLOWED_PLACE_ID = tonumber("placeid")

Replace ONLY "placeid" with your numeric Roblox PlaceId in the main file.
Do the same for:
local ALLOWED_PLACE_ID = tonumber("placeid")
inside the server fling component.

FINAL BATCH INCLUDES
- Mini tab stays perfectly circular at every size.
- Smaller deliberate resize grip + drag jitter protection.
- Arabic/Russian translation cleanup and more dynamic translated statuses.
- AUTO DODGE in TROLL:
  Model named Sword only, editable radius/distance, floating DODGE button.
- SERVER FLING in TROLL:
  target picker, editable power 60-260, cooldown, server authorization,
  target validation, immunity attributes, server responses.
- Error notification system:
  red error toasts, repeated-error suppression, error sound.
- Error sound Settings toggle and sound selector with instant preview.
- Default sound: RUBY ALERT (85552330273422)
- VOID PULSE (79908084264003)
- SYSTEM GLITCH (134254842665299)
- CRITICAL SIGNAL (91681144991126)
- NEON WARNING (131447940085093)
- EXECUTOR ALERT (92466756400564)
- Aimbot/Aim Assist missing-target errors.
- Auto Shoot missing-weapon / missing-aim-mode errors.
- Late-created Shooter features now join Search/Favorites.

NOTE
The files were statically checked for balanced Lua/Luau blocks/brackets and the
main script remains at 195 top-level locals. Live Roblox runtime behavior cannot
be fully tested here. Roblox audio permissions can also affect whether a given
audio asset plays in an experience.
